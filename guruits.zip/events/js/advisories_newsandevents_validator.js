
$(document).ready(function(){
	
   
	
	$("#save").click(function()
    {
        $("#frmvalue").submit(function()
        {
         if(!$("#headerlist").val()){		
			$(".update-advisories-header").text("*Advisory header is required");
			return false;				
		}
		
		else {
			$(".contact-form-captcha-message").hide();
		}
        });     
        $("#frmvalue").submit(); //invoke form submission
 
    });

    
});



	
